# ForgeOps Automation

A lightweight Python automation toolkit that covers both "server/agent" and "server-less" execution models. The current drop focuses on local (server-less) execution, laying the groundwork for daemonized agents by using executor abstractions throughout the code.

## Highlights

- Minimal dependencies (standard library only) for quick bootstrapping.
- Declarative plan files written in TOML describing hosts, tasks, and actions.
- Pluggable executor abstraction – today a `LocalExecutor`, with hooks for future agent/server transport.
- First-class operations for package installation/removal and file management.
- Built-in dry-run flag so you can validate idempotent behavior before touching a node.

## Project layout

```
pyproject.toml                 # Packaging metadata and CLI entrypoint
src/forgeops_automation/       # Python package with runners, executors, and operations
examples/base_plan.toml        # Sample plan exercising package & file management
```

### Plans

Plans are TOML documents with two sections:

```toml
[hosts.local]
connection = "local"

[[tasks]]
name = "bootstrap"
hosts = ["local"]

  [[tasks.actions]]
  type = "package"
  packages = ["git", "python3"]

  [[tasks.actions]]
  type = "file"
  path = "/tmp/motd"
  state = "present"
  mode = "0644"
  content = "Welcome to ForgeOps"
```

Each action maps to an operation defined under `src/forgeops_automation/operations`. Unknown actions raise an error early, which makes plan validation explicit.

## Usage

1. Install the project (editable is convenient during development):

   ```bash
   pip install -e .
   ```

2. Run the CLI against a plan:

   ```bash
   forgeops-auto examples/base_plan.toml --dry-run
   ```

3. Drop the `--dry-run` flag when you are ready to apply changes locally.

The CLI returns zero on success and prints a concise status line per host/action pair.

### Tests

Unit tests live under `tests/` and use `pytest`:

```bash
PYTHONPATH=src pytest
```

The suite covers the inventory loader, file and package operations, and runner plumbing so regression signals stay quick.

### System CLI script

For environments where you want a simple `/usr/bin/forgeops-auto`, ship the `scripts/forgeops-auto` helper along with the installed package. The script is a tiny Python entry point that calls `forgeops_automation.cli.main`, so placing it in your `$PATH` (or symlinking it) immediately exposes the same flags as the packaged console entry point.

### RPM packaging helper

Need to ship your automation bits as an RPM (RHEL 8 / Amazon Linux 2023)? Use `scripts/build_rpm.sh` with a payload directory that mirrors the desired filesystem layout:

```bash
mkdir -p payload/usr/local/bin
cp scripts/forgeops-auto payload/usr/local/bin/
scripts/build_rpm.sh --name forgeops-auto --version 0.1.0 --payload payload \
  --summary "ForgeOps CLI" --description "Lightweight automation helper" \
  --dist-tag .amzn2023
```

The script wraps `rpmbuild`, autogenerates a spec file, and drops the finished RPM in `./dist/`. Additional flags let you set release numbers, scriptlets, vendor/URL metadata, distro suffixes (e.g. `--dist-tag .amzn2023`), and custom work/output directories.

## Extending toward agents or server mode

- Executors live in `src/forgeops_automation/executors.py`. Implement a subclass that knows how to talk to your agent (gRPC, SSH, message bus, etc.) and return it from `TaskRunner._executor_for` for connection types such as `agent` or `server`.
- Operations are regular Python classes. Additional actions – service management, templating, orchestration hooks – can be registered by adding them to `OPERATION_REGISTRY`.

## Next ideas

- Inventory caching and fact gathering for agent-based runs.
- State reporting endpoint so a controller can fan out work to remote agents.
- Unit tests around the package and file operations.
- Support for templated file content (Jinja) and richer package providers (pip, npm, etc.).
